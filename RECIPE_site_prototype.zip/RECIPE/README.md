# RE:CIPE prototype

A responsive single-page prototype for RE:CIPE.

## Run
Open `index.html` in a modern browser.

## Included
- Home page with randomized tagline and animated wordmark
- Shared navigation
- Ingredient list UI for recipe recommendations
- Recipe variation form with ingredient replacement / ratio-change modes
- Photo preview upload (no OCR)
- Rule-based sample output, warnings, and copy result
- Responsive layout with pixel-art SVG food decorations

## Not connected yet
- AI recipe analysis
- OCR / image-to-text recognition
- Recipe database or recommendation engine
- Server-side API

For public hosting, upload this folder to a static host such as GitHub Pages. The prototype does not require a build step.
